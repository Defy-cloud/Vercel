# Vaunt Scripts — Deploy Guide

## What this does
- Upload page: paste or drag a .lua/.txt script → get a raw link
- Raw link: returns plain script text to executors (game:HttpGet)
- Browser access: shows "🔒 Auth Only" page — source is hidden

---

## Deploy Steps (5 minutes)

### 1. Create Upstash Redis (free)
1. Go to https://upstash.com → Sign up free
2. Click "Create Database"
3. Name it anything, pick a region close to you
4. Click the database → go to "REST API" tab
5. Copy **UPSTASH_REDIS_REST_URL** and **UPSTASH_REDIS_REST_TOKEN**

### 2. Push to GitHub
1. Go to https://github.com/new → create a new repo (e.g. `vaunt-scripts`)
2. Upload all files from this folder into that repo
   - Or use: `git init`, `git add .`, `git commit -m "init"`, `git push`

### 3. Deploy on Vercel
1. Go to https://vercel.com → Sign up / Log in with GitHub
2. Click "Add New Project" → Import your GitHub repo
3. Framework: **Next.js** (auto-detected)
4. Before clicking Deploy, click **"Environment Variables"** and add:
   ```
   UPSTASH_REDIS_REST_URL     = (paste from Upstash)
   UPSTASH_REDIS_REST_TOKEN   = (paste from Upstash)
   ```
5. Click **Deploy** — done!

---

## Usage

### Upload a script
1. Open your Vercel URL (e.g. `https://vaunt-scripts.vercel.app`)
2. Paste script or drag a .lua/.txt file
3. Click **↑ UPLOAD**
4. Copy the raw link or the loadstring

### Execute in Roblox
```lua
loadstring(game:HttpGet("https://vaunt-scripts.vercel.app/api/raw/YOUR_ID"))()
```

### What browsers see
Anyone opening the raw link in a browser gets a "🔒 AUTH ONLY" page.
Only Roblox executors (which send Roblox/blank user-agents) get the actual script.

---

## File structure
```
pages/
  index.tsx          ← upload UI
  _app.tsx
  api/
    upload.ts        ← POST /api/upload  { content } → { id }
    raw/
      [id].ts        ← GET /api/raw/:id  → script or Auth Only page
lib/
  redis.ts           ← Upstash Redis client
```
