import type { NextApiRequest, NextApiResponse } from 'next'
import { v4 as uuidv4 } from 'uuid'
import redis from '../../lib/redis'

export const config = { api: { bodyParser: { sizeLimit: '2mb' } } }

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  if (req.method !== 'POST') return res.status(405).end()

  const { content } = req.body as { content?: string }
  if (!content || typeof content !== 'string' || content.trim() === '') {
    return res.status(400).json({ error: 'No content provided' })
  }

  const id = uuidv4().replace(/-/g, '').slice(0, 16)
  await redis.set(`script:${id}`, content)

  return res.status(200).json({ id })
}
