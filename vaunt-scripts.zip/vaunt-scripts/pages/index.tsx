import { useState, useRef, useCallback } from 'react'
import Head from 'next/head'

export default function Home() {
  const [content, setContent] = useState('')
  const [link, setLink] = useState('')
  const [status, setStatus] = useState<'idle' | 'loading' | 'done' | 'error'>('idle')
  const [copied, setCopied] = useState(false)
  const [draggingOver, setDraggingOver] = useState(false)
  const fileRef = useRef<HTMLInputElement>(null)

  const readFile = (file: File) => {
    const reader = new FileReader()
    reader.onload = e => setContent(e.target?.result as string ?? '')
    reader.readAsText(file)
  }

  const onDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault()
    setDraggingOver(false)
    const file = e.dataTransfer.files[0]
    if (file) readFile(file)
  }, [])

  const upload = async () => {
    if (!content.trim()) return
    setStatus('loading')
    setLink('')
    try {
      const res = await fetch('/api/upload', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ content }),
      })
      if (!res.ok) throw new Error()
      const { id } = await res.json()
      const raw = `${window.location.origin}/api/raw/${id}`
      setLink(raw)
      setStatus('done')
    } catch {
      setStatus('error')
    }
  }

  const copy = () => {
    navigator.clipboard.writeText(link)
    setCopied(true)
    setTimeout(() => setCopied(false), 2000)
  }

  const copyHttpGet = () => {
    navigator.clipboard.writeText(`loadstring(game:HttpGet("${link}"))()`)
    setCopied(true)
    setTimeout(() => setCopied(false), 2000)
  }

  return (
    <>
      <Head>
        <title>Vaunt Scripts</title>
        <meta name="viewport" content="width=device-width, initial-scale=1" />
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="anonymous" />
        <link href="https://fonts.googleapis.com/css2?family=JetBrains+Mono:wght@400;600;700&family=Syne:wght@600;800&display=swap" rel="stylesheet" />
      </Head>

      <style jsx global>{`
        *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }
        body {
          background: #07080e;
          min-height: 100vh;
          font-family: 'JetBrains Mono', monospace;
          color: #c8cde8;
          overflow-x: hidden;
        }
        body::before {
          content: '';
          position: fixed;
          inset: 0;
          background:
            radial-gradient(ellipse 60% 40% at 20% 10%, #0047cc18 0%, transparent 60%),
            radial-gradient(ellipse 50% 50% at 80% 80%, #00c4ff0d 0%, transparent 60%);
          pointer-events: none;
          z-index: 0;
        }
        ::-webkit-scrollbar { width: 4px; }
        ::-webkit-scrollbar-track { background: #0d0f1a; }
        ::-webkit-scrollbar-thumb { background: #1e2240; border-radius: 4px; }
        textarea {
          font-family: 'JetBrains Mono', monospace !important;
          resize: none;
          outline: none;
          border: none;
        }
        textarea::placeholder { color: #2e3354; }
        @keyframes fadeUp {
          from { opacity: 0; transform: translateY(16px); }
          to   { opacity: 1; transform: translateY(0); }
        }
        @keyframes spin {
          to { transform: rotate(360deg); }
        }
        @keyframes glow {
          0%,100% { box-shadow: 0 0 0 0 #0060ff40; }
          50%      { box-shadow: 0 0 0 8px #0060ff00; }
        }
      `}</style>

      <main style={{
        position: 'relative', zIndex: 1,
        minHeight: '100vh',
        display: 'flex', flexDirection: 'column',
        alignItems: 'center', justifyContent: 'center',
        padding: '32px 16px',
      }}>

        {/* Header */}
        <div style={{ textAlign: 'center', marginBottom: '36px', animation: 'fadeUp .5s ease both' }}>
          <div style={{
            display: 'inline-flex', alignItems: 'center', gap: '10px',
            background: '#0d0f1a', border: '1px solid #1a1d2e',
            borderRadius: '999px', padding: '6px 16px',
            fontSize: '11px', letterSpacing: '2px', color: '#3a6fff',
            marginBottom: '20px', textTransform: 'uppercase',
          }}>
            <span style={{ width: 6, height: 6, borderRadius: '50%', background: '#3a6fff', display: 'inline-block', animation: 'glow 2s ease infinite' }} />
            Vaunt Scripts
          </div>
          <h1 style={{
            fontFamily: 'Syne, sans-serif',
            fontSize: 'clamp(28px, 5vw, 46px)',
            fontWeight: 800,
            color: '#e8ecff',
            letterSpacing: '-1px',
            lineHeight: 1.1,
            marginBottom: '10px',
          }}>
            Script Uploader
          </h1>
          <p style={{ color: '#3d4265', fontSize: '13px', letterSpacing: '0.5px' }}>
            Upload · Get raw link · Execute in Roblox
          </p>
        </div>

        {/* Card */}
        <div style={{
          width: '100%', maxWidth: '680px',
          background: '#0b0d16',
          border: '1px solid #151828',
          borderRadius: '20px',
          overflow: 'hidden',
          animation: 'fadeUp .5s ease .1s both',
          boxShadow: '0 32px 80px #00000080',
        }}>

          {/* Card header */}
          <div style={{
            padding: '18px 24px',
            borderBottom: '1px solid #131524',
            display: 'flex', alignItems: 'center', gap: '10px',
          }}>
            <div style={{ display: 'flex', gap: '6px' }}>
              {['#ff5f57','#febc2e','#28c840'].map(c => (
                <div key={c} style={{ width: 10, height: 10, borderRadius: '50%', background: c, opacity: .7 }} />
              ))}
            </div>
            <span style={{ fontSize: '11px', color: '#2a2f4a', letterSpacing: '1px', marginLeft: '4px' }}>
              script.lua
            </span>
          </div>

          {/* Drop zone */}
          <div
            onDragOver={e => { e.preventDefault(); setDraggingOver(true) }}
            onDragLeave={() => setDraggingOver(false)}
            onDrop={onDrop}
            style={{
              position: 'relative',
              margin: '20px',
              borderRadius: '12px',
              border: `1px solid ${draggingOver ? '#3a6fff' : '#161928'}`,
              background: draggingOver ? '#0d1530' : '#090b14',
              transition: 'all .2s',
            }}
          >
            <textarea
              value={content}
              onChange={e => setContent(e.target.value)}
              placeholder="-- Paste your Lua script here..."
              rows={14}
              style={{
                width: '100%',
                background: 'transparent',
                color: '#a8b0d8',
                fontSize: '13px',
                lineHeight: '1.7',
                padding: '18px',
                borderRadius: '12px',
              }}
            />
            {!content && (
              <div style={{
                position: 'absolute', inset: 0,
                display: 'flex', flexDirection: 'column',
                alignItems: 'center', justifyContent: 'center',
                pointerEvents: 'none', gap: '8px',
                opacity: draggingOver ? 1 : 0,
                transition: 'opacity .2s',
              }}>
                <div style={{ fontSize: '32px' }}>📂</div>
                <span style={{ color: '#3a6fff', fontSize: '13px' }}>Drop file here</span>
              </div>
            )}
          </div>

          {/* Actions */}
          <div style={{
            padding: '0 20px 20px',
            display: 'flex', gap: '10px', flexWrap: 'wrap',
          }}>
            {/* File upload */}
            <button
              onClick={() => fileRef.current?.click()}
              style={{
                background: '#111420', border: '1px solid #1e2240',
                color: '#5a6090', borderRadius: '10px',
                padding: '10px 18px', fontSize: '12px',
                cursor: 'pointer', letterSpacing: '.5px',
                transition: 'all .15s',
              }}
              onMouseEnter={e => (e.currentTarget.style.borderColor = '#3a6fff')}
              onMouseLeave={e => (e.currentTarget.style.borderColor = '#1e2240')}
            >
              📁 Browse File
            </button>
            <input
              ref={fileRef} type="file"
              accept=".lua,.txt"
              style={{ display: 'none' }}
              onChange={e => { const f = e.target.files?.[0]; if (f) readFile(f) }}
            />

            {/* Clear */}
            {content && (
              <button
                onClick={() => { setContent(''); setLink(''); setStatus('idle') }}
                style={{
                  background: '#111420', border: '1px solid #1e2240',
                  color: '#5a6090', borderRadius: '10px',
                  padding: '10px 18px', fontSize: '12px',
                  cursor: 'pointer', letterSpacing: '.5px',
                  transition: 'all .15s',
                }}
                onMouseEnter={e => (e.currentTarget.style.borderColor = '#ff4444')}
                onMouseLeave={e => (e.currentTarget.style.borderColor = '#1e2240')}
              >
                ✕ Clear
              </button>
            )}

            {/* Upload — pushed right */}
            <button
              onClick={upload}
              disabled={!content.trim() || status === 'loading'}
              style={{
                marginLeft: 'auto',
                background: content.trim() ? 'linear-gradient(135deg, #0055ff, #0099ff)' : '#111420',
                border: '1px solid transparent',
                color: content.trim() ? '#fff' : '#2a2f4a',
                borderRadius: '10px',
                padding: '10px 28px', fontSize: '12px',
                cursor: content.trim() ? 'pointer' : 'not-allowed',
                letterSpacing: '1px', fontWeight: 700,
                transition: 'all .2s',
                fontFamily: 'JetBrains Mono, monospace',
              }}
            >
              {status === 'loading'
                ? <span style={{ display: 'inline-block', width: 14, height: 14, border: '2px solid #fff4', borderTopColor: '#fff', borderRadius: '50%', animation: 'spin .6s linear infinite' }} />
                : '↑ UPLOAD'}
            </button>
          </div>

          {/* Result */}
          {status === 'done' && link && (
            <div style={{
              margin: '0 20px 20px',
              background: '#08101f',
              border: '1px solid #0e2040',
              borderRadius: '12px',
              padding: '16px 18px',
              animation: 'fadeUp .3s ease both',
            }}>
              <div style={{ fontSize: '11px', color: '#2a4a80', letterSpacing: '1px', marginBottom: '10px', textTransform: 'uppercase' }}>
                ✓ Uploaded — Raw Link
              </div>

              {/* Raw URL */}
              <div style={{
                display: 'flex', gap: '8px', alignItems: 'center',
                marginBottom: '10px',
              }}>
                <div style={{
                  flex: 1, background: '#050810',
                  border: '1px solid #0e1830',
                  borderRadius: '8px', padding: '10px 14px',
                  fontSize: '12px', color: '#4a80cc',
                  overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap',
                }}>
                  {link}
                </div>
                <button
                  onClick={copy}
                  style={{
                    background: '#0a1428', border: '1px solid #0e2040',
                    color: copied ? '#28c840' : '#4a80cc',
                    borderRadius: '8px', padding: '10px 14px',
                    fontSize: '11px', cursor: 'pointer',
                    whiteSpace: 'nowrap', transition: 'all .15s',
                    fontFamily: 'JetBrains Mono, monospace',
                  }}
                >
                  {copied ? '✓ Copied' : 'Copy URL'}
                </button>
              </div>

              {/* loadstring */}
              <div style={{
                background: '#050810',
                border: '1px solid #0e1830',
                borderRadius: '8px', padding: '10px 14px',
                fontSize: '12px', color: '#3a5090',
                display: 'flex', justifyContent: 'space-between', alignItems: 'center', gap: '8px',
              }}>
                <span style={{ overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap', flex: 1 }}>
                  {`loadstring(game:HttpGet("${link}"})()`}
                </span>
                <button
                  onClick={copyHttpGet}
                  style={{
                    background: '#0a1428', border: '1px solid #0e2040',
                    color: '#3a6fff', borderRadius: '6px',
                    padding: '6px 12px', fontSize: '11px',
                    cursor: 'pointer', whiteSpace: 'nowrap',
                    transition: 'all .15s',
                    fontFamily: 'JetBrains Mono, monospace',
                  }}
                >
                  Copy loadstring
                </button>
              </div>

              <div style={{ marginTop: '12px', fontSize: '11px', color: '#1e2a40', letterSpacing: '.5px' }}>
                🔒 Browser access returns "Auth Only" — only executors can read this
              </div>
            </div>
          )}

          {status === 'error' && (
            <div style={{
              margin: '0 20px 20px', padding: '12px 16px',
              background: '#180808', border: '1px solid #400',
              borderRadius: '10px', color: '#ff6060', fontSize: '12px',
            }}>
              Upload failed. Check your Redis connection.
            </div>
          )}
        </div>

        {/* Footer */}
        <div style={{
          marginTop: '32px', fontSize: '11px',
          color: '#1e2240', letterSpacing: '1px',
          animation: 'fadeUp .5s ease .2s both',
        }}>
          VAUNT SCRIPTS — EXECUTOR AUTH ONLY
        </div>
      </main>
    </>
  )
}
