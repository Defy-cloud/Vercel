import type { NextApiRequest, NextApiResponse } from 'next'
import redis from '../../lib/redis'

// Known Roblox / executor HTTP user-agent substrings
const EXECUTOR_AGENTS = [
  'roblox',
  'exploitfix',
  'synapse',
  'krnl',
  'fluxus',
  'arceus',
  'scriptware',
  'oxygen',
  'electron',
  'wave',
  'comet',
  'delta',
  'hydrogen',
  'solara',
  'evon',
  'codex',
]

function isExecutor(ua: string): boolean {
  const lower = ua.toLowerCase()
  // game:HttpGet sends "RobloxApp" or blank UA
  if (lower === '' || lower.includes('roblox')) return true
  return EXECUTOR_AGENTS.some(e => lower.includes(e))
}

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  const { id } = req.query as { id: string }
  if (!id) return res.status(400).end()

  const ua = (req.headers['user-agent'] ?? '').toLowerCase()

  // Block browsers
  if (!isExecutor(ua)) {
    res.setHeader('Content-Type', 'text/html; charset=utf-8')
    return res.status(403).send(`<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8"/>
<meta name="viewport" content="width=device-width,initial-scale=1"/>
<title>Auth Only</title>
<style>
  *{margin:0;padding:0;box-sizing:border-box}
  body{background:#090a0f;display:flex;align-items:center;justify-content:center;min-height:100vh;font-family:'Courier New',monospace}
  .card{text-align:center;padding:48px 40px;border:1px solid #1a1d2e;border-radius:16px;background:#0d0f1a}
  .lock{font-size:52px;margin-bottom:24px;filter:drop-shadow(0 0 18px #0078ff88)}
  h1{color:#e0e4ff;font-size:22px;letter-spacing:2px;font-weight:700;margin-bottom:10px}
  p{color:#555870;font-size:13px;letter-spacing:1px}
  .dot{display:inline-block;width:6px;height:6px;border-radius:50%;background:#0078ff;margin:24px 4px 0;animation:pulse 1.4s ease-in-out infinite}
  .dot:nth-child(2){animation-delay:.2s}.dot:nth-child(3){animation-delay:.4s}
  @keyframes pulse{0%,100%{opacity:.2;transform:scale(.8)}50%{opacity:1;transform:scale(1.2)}}
</style>
</head>
<body>
<div class="card">
  <div class="lock">🔒</div>
  <h1>AUTH ONLY</h1>
  <p>This resource is restricted to authorized executors.</p>
  <span class="dot"></span><span class="dot"></span><span class="dot"></span>
</div>
</body>
</html>`)
  }

  const content = await redis.get<string>(`script:${id}`)
  if (!content) return res.status(404).end()

  res.setHeader('Content-Type', 'text/plain; charset=utf-8')
  res.setHeader('Cache-Control', 'no-store')
  return res.status(200).send(content)
}
